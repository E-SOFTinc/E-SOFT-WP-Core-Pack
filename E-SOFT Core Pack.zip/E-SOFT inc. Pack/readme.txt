=== Plugin Name ===
Contributors: MrYann
Donate link: http://e-soft.ca/
Tags: 
Requires at least: 4.1
Tested up to: 4.1
Stable tag: 0.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin is a Wordpress Tool Pack for E-SOFT's clients

== Description ==
== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload `plugin-name.php` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Find Tools info in the new E-SOFT inc. Backend Menu

== Frequently Asked Questions ==

= A question that someone might have =

An answer to that question.

= What about foo bar? =

Answer to foo bar dilemma.

== Screenshots ==

== Changelog ==

= 0.4 =
* First version for wordpress.org plugins

== Upgrade Notice ==

Here's a link to [WordPress](http://e-soft.ca/ "E-SOFT inc.".
Titles are optional, naturally.


`<?php code(); // goes in backticks ?>`
